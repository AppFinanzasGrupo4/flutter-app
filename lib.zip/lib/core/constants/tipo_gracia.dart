enum TipoGracia { ninguna, parcial, total }
