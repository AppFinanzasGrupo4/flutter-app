const monedas = ['PEN', 'USD', 'EUR', 'JPY', 'CLP', 'MXN', 'ARS', 'BRL'];
